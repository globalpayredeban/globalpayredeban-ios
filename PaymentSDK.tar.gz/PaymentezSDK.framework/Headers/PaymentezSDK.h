//
//  PaymentezSDK.h
//  PaymentezSDK
//
//  Created by Gustavo Sotelo on 09/05/16.
//  Copyright © 2016 Paymentez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KDataCollector.h"
#import "CardIO.h"


//! Project version number for PaymentezSDK.
FOUNDATION_EXPORT double PaymentezSDKVersionNumber;

//! Project version string for PaymentezSDK.
FOUNDATION_EXPORT const unsigned char PaymentezSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaymentezSDK/PublicHeader.h>


