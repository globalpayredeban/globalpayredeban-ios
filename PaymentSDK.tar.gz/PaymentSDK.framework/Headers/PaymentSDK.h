//
//  PaymentSDK.h
//  PaymentSDK
//
//  Created by Gustavo Sotelo on 09/05/16.
//  Copyright © 2016 Payment. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KDataCollector.h"
#import "CardIO.h"


//! Project version number for PaymentSDK.
FOUNDATION_EXPORT double PaymentSDKVersionNumber;

//! Project version string for PaymentSDK.
FOUNDATION_EXPORT const unsigned char PaymentSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaymentSDK/PublicHeader.h>


